ontospy gendocs OntoSMP.rdf -o docs --type 2
zip -r docs.zip docs
