pip install ontospy
